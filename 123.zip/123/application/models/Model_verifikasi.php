<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_verifikasi extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function add_user($data)
    {
        // insert data ke tabel user
        $this->db->insert('user', $data);
    }

    public function update_user($data, $user_id)
    {
        // Pastikan $data adalah array yang sesuai dengan struktur tabel
        // Juga pastikan $user_id sesuai dengan kondisi WHERE pada pembaruan data
        $this->db->where('userID', $user_id);
        $this->db->update('user', $data);
    }

    public function Get_userByusername($username)
    {

        $query =  $this->db->get_where('user', ['user_username' => $username]);
        return $query->row();
    }

    public function Get_komen($komenID)
    {
        return $this->db->get_where('komentar', ['komentarID' => $komenID])->row();
    }

    public function Get_userdata()
    {
        $this->db->get('user');
    }
    
    public function Get_userdataID($user_id)
    {
        // Query database to get user data based on user ID
        $query = $this->db->get_where('user', array('userID' => $user_id));

        // Check if data is found
        if ($query->num_rows() > 0) {
            return $query->row(); // Return user data
        } else {
            return null; // Return null if user data is not found
        }
    }

    public function checklogin()
    {
        if (!$this->session->userdata('user_id')) {
            $this->session->set_flashdata('psn login', 'You Must Login first');
            redirect('Auth/Login');
        }
    }

    public function is_data_changed($new_data)
    {
        // Get existing user data from the database based on the user ID
        $user_id = $this->session->userdata('user_id');
        $existing_data = $this->Get_userdataID($user_id); // You need to implement this method

        // Compare each field to check for changes
        foreach ($new_data as $field => $value) {
            if (isset($existing_data->$field) && $existing_data->$field !== $value) {
                return true; // Data has changed
            }
        }

        return false; // No changes detected
    }

    public function GetuserID_foto($fotoID,$userID)
    {
        $this->db->select('userID');
        $this->db->where('fotoID', $fotoID);
        $this->db->where('userID', $userID);
        $query = $this->db->get('foto');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->userID;
        } else {
            return null;
        }
    }

    public function GetuserID_album($albumID,$userID)
    {
        $this->db->select('userID');
        $this->db->where('albumID', $albumID);
        $this->db->where('userID', $userID);
        $query = $this->db->get('album');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->userID;
        } else {
            return null;
        }
    }
}
