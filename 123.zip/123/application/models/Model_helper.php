<?php
class Model_helper extends CI_Model
{
    public function setpesan($key, $message)
    {
        $this->session->set_flashdata($key, $message);
    }

    public function showpesan($key, $class = 'info')
    {
        $message = $this->session->flashdata($key);

        if ($message) {
            return '<div class="alert alert-' . $class . ' alert-dismissible" role="alert" style="width: 300px; height: 50px">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        ' . $message . '
                    </div>';
        }
        return '';
    }

    public function getAlbum()
    {
        $queryalbum = $this->db->get('album');
        return $queryalbum->result();
    }

    public function getKategori()
    {
        $query = $this->db->get('kategori');
        return $query->result();
    }
}
