<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_gallery extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function insert_image($data)
    {
        $this->db->insert('foto', $data);
        return $this->db->affected_rows() > 0;
    }

    public function insert_album($data)
    {
        $this->db->insert('album', $data);
        return $this->db->affected_rows() > 0;
    }

    public function insert_komen($data)
    {
        $this->db->insert('komentar', $data);
    }

    public function get_count_all()
    {
        return $this->db->count_all_results('foto');
    }

    public function get_count_album()
    {
        return $this->db->count_all_results('album');
    }

    public function CountBykategori($kategoriID)
    {
        if ($kategoriID !== null) {
            $this->db->where('kategoriID', $kategoriID);
        }
        return $this->db->count_all_results('foto');
    }

    public function getAllPhotos($limit, $start)
    {
        $this->db->select('user.user_username, user.userID, user.user_namalengkap, foto.*, kategori.kategori_nama, COUNT(likefoto.likeID) as jumlah_like, COUNT(komentar.komentarID) as jumlah_komentar');
        $this->db->select("DATE_FORMAT(foto.foto_tanggal, '%W, %e %M') as foto_tanggal", FALSE);
        $this->db->from('foto');
        $this->db->join('user', 'user.userID = foto.userID', 'left');
        $this->db->join('kategori', 'foto.kategoriID = kategori.kategoriID', 'left');
        $this->db->join('likefoto', 'likefoto.fotoID = foto.fotoID', 'left');
        $this->db->join('komentar', 'komentar.fotoID = foto.fotoID', 'left');
        $this->db->group_by('foto.fotoID'); // Group by to get distinct photos
        $this->db->order_by('foto.fotoID', 'DESC'); // Order by photo ID descending
        $this->db->limit($limit, $start);
        $query = $this->db->get();

        return $query->result();
    }

    public function getAllPhotosbyKatgeori($limit, $start, $kategoriID = NULL)
    {
        if ($kategoriID !== NULL) {
            $this->db->where('foto.kategoriID', $kategoriID); // Specify the table for kategoriID
        }
        $this->db->select('user.user_username, user.userID, user.user_namalengkap, foto.*, kategori.kategori_nama, COUNT(likefoto.likeID) as jumlah_like, COUNT(komentar.komentarID) as jumlah_komentar');
        $this->db->select("DATE_FORMAT(foto.foto_tanggal, '%W, %e %M') as foto_tanggal", FALSE);
        $this->db->from('foto');
        $this->db->join('user', 'user.userID = foto.userID', 'left');
        $this->db->join('kategori', 'foto.kategoriID = kategori.kategoriID', 'left');
        $this->db->join('likefoto', 'likefoto.fotoID = foto.fotoID', 'left');
        $this->db->join('komentar', 'komentar.fotoID = foto.fotoID', 'left');
        $this->db->group_by('foto.fotoID'); // Group by to get distinct photos
        $this->db->order_by('foto.fotoID', 'DESC'); // Order by photo ID descending
        $this->db->limit($limit, $start);
        $query = $this->db->get();

        return $query->result();
    }

    public function getUserPhotos($userID)
    {
        $this->db->where('foto.userID', $userID);
        $this->db->select('user.user_username, user.userID, user.user_namalengkap, user.user_avatar, foto.*');
        $this->db->select("DATE_FORMAT(foto.foto_tanggal, '%W, %e %M') as foto_tanggal", FALSE);
        $this->db->from('foto');
        $this->db->join('user', 'user.userID = foto.userID', 'left');
        $query = $this->db->get();

        return $query->result();
    }

    public function getPhotosByLikes()
    {
        $this->db->select('user.user_username, user.userID, user.user_namalengkap, foto.*, kategori.kategori_nama, COUNT(likefoto.likeID) as jumlah_like, COUNT(komentar.komentarID) as jumlah_komentar');
        $this->db->select("DATE_FORMAT(foto.foto_tanggal, '%W, %e %M') as foto_tanggal", FALSE);
        $this->db->from('foto');
        $this->db->join('user', 'user.userID = foto.userID', 'left');
        $this->db->join('kategori', 'foto.kategoriID = kategori.kategoriID', 'left');
        $this->db->join('likefoto', 'likefoto.fotoID = foto.fotoID', 'left');
        $this->db->join('komentar', 'komentar.fotoID = foto.fotoID', 'left');
        $this->db->group_by('foto.fotoID'); // Group by to get distinct photos
        $this->db->order_by('jumlah_like', 'DESC');
        $this->db->limit(3);
        $query = $this->db->get();

        return $query->result();
    }

    public function gefotoByalbum($albumID)
    {
        return $this->db->get_where('album',['albumID' => $albumID])->row();
    }

    public function GetAllKomen()
    {
        $this->db->select('user.user_username, user.userID, user.user_avatar,komentar.komentarID, komentar.komentar_isi, komentar.userID, komentar.fotoID, komentar.komentar_tanggal,
            foto.fotoID, foto.userID, COUNT(komentar.komentarID) as jumlah_komentar');
        $this->db->from('komentar');
        $this->db->join('user', 'user.userID = komentar.userID', 'left');
        $this->db->join('foto', 'foto.fotoID = komentar.fotoID', 'left');
        $this->db->group_by('komentar.komentarID'); // Adjusted group by to avoid grouping issues
        $query = $this->db->get();

        return $query->result();
    }

    public function GetAlbums($limit, $start)
    {
        $this->db->select('user.*, album.*,foto.*, COUNT(foto.foto_lokasi) as jumlah_foto');
        $this->db->from('album');
        $this->db->join('user', 'user.userID = album.userID', 'left');
        $this->db->join('foto', 'foto.albumID = album.albumID', 'left');
        $this->db->group_by('album.albumID, user.userID');  
        $this->db->limit($limit, $start);

        $query = $this->db->get();
        return $query->result();
    }

    public function GetalbumUser($userID)
    {
        $this->db->where('album.userID',$userID);
        $this->db->select('user.*,album.*');
        $this->db->from('album');
        $this->db->join('user','user.userID = album.userID');
        $query = $this->db->get();

        return $query->result();

    }

    public function GetFotoID($albumID, $i)
    {
        
        $this->db->select('fotoID');
        $this->db->from('foto');
        $this->db->where('albumID', $albumID);
        $this->db->limit(1, $i);
        $query = $this->db->get();

         return $query->num_rows() > 0 ? $query->row()->fotoID : null;
    }

    public function GetFotoLokasi($fotoID)
    {
         $this->db->select('foto_lokasi');
        $this->db->from('foto');
        $this->db->where('fotoID', $fotoID);
        $query = $this->db->get();

         return $query->num_rows() > 0 ? $query->row()->foto_lokasi : null;
    }
}
