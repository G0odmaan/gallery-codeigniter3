<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('Model_verifikasi');
        $this->load->model('Model_gallery');
        $this->Model_verifikasi->checklogin();
        $this->load->model('Model_helper');
        $this->load->library("pagination");
     }

    public function index()
    {
        // $data['user']  = $this->db->get_where('user', ['username' =>
        // $this->session->userdata('username')])->row_array();
        $data['user'] = $this->db->get_where('user', ['user_username' => $this->session->userdata('username')])->row_array();
        $data['title'] = "Gallery | Home";
        $this->load->view('templates/header', $data);
        $this->load->view('templates/navbar');
        $this->load->view('index');
        $this->load->view('templates/footer');
    }

    public function searchphoto()
    {
        // Mendapatkan data pengguna berdasarkan session
        $data['user'] = $this->db->get_where('user', ['user_username' => $this->session->userdata('username')])->row_array();
        $data['album'] = $this->Model_helper->getAlbum();
        $data['kategori'] = $this->Model_helper->getKategori();
        $data['komentar'] = $this->Model_gallery->GetAllKomen();
        // ====== Pagination Configuration
        $config["base_url"] = base_url('User/searchphoto');
        $config["total_rows"] = $this->Model_gallery->get_count_all();
        $config["per_page"] = 6;
        $config["uri_segment"] = 3;
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close'] = '</span></li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close'] = '</span></li>';
        $config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close'] = '</span></li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close'] = '</span></li>';
        $this->pagination->initialize($config);
    
        // Mendapatkan data foto dengan menggunakan metode GetAllphoto dengan pagination
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data['foto'] = $this->Model_gallery->getAllPhotos($config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();
        // ========
    
        $data['title'] = "Gallery | Searchphoto";
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/navbar');
        $this->load->view('searchphoto');
        $this->load->view('templates/footer');
    }

    public function album_page()
    {
                // Mendapatkan data pengguna berdasarkan session
                $data['user'] = $this->db->get_where('user', ['user_username' => $this->session->userdata('username')])->row_array();
                // ====== Pagination Configuration
                $config["base_url"] = base_url('User/searchphoto');
                $config["total_rows"] = $this->Model_gallery->get_count_album();
                $config["per_page"] = 6;
                $config["uri_segment"] = 3;
                $config['full_tag_open'] = '<ul class="pagination">';
                $config['full_tag_close'] = '</ul>';
                $config['first_link'] = 'First';
                $config['last_link'] = 'Last';
                $config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
                $config['first_tag_close'] = '</span></li>';
                $config['prev_link'] = '&laquo';
                $config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
                $config['prev_tag_close'] = '</span></li>';
                $config['next_link'] = '&raquo';
                $config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
                $config['next_tag_close'] = '</span></li>';
                $config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
                $config['last_tag_close'] = '</span></li>';
                $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
                $config['cur_tag_close'] = '</a></li>';
                $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
                $config['num_tag_close'] = '</span></li>';
                $this->pagination->initialize($config);
            
                // Mendapatkan data foto dengan menggunakan metode GetAllphoto dengan pagination
                $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['album'] = $this->Model_gallery->GetAlbums($config["per_page"], $page);
                $data["links"] = $this->pagination->create_links();
                // ========
            
                $data['title'] = "Gallery | Searchphoto";
            
                $this->load->view('templates/header', $data);
                $this->load->view('templates/navbar');
                $this->load->view('album_page');
                $this->load->view('templates/footer');

    }
    
    public function my_gallery($userID)
    {
        $data['user'] = $this->db->get_where('user', ['user_username' => $this->session->userdata('username')])->row_array();
        $data['title'] = "Gallery | My Gallery";
        $data['foto'] = $this->Model_gallery->getUserPhotos($userID);
        $data['album'] = $this->Model_gallery->GetalbumUser($userID);
        $this->load->view('templates/header', $data);
        $this->load->view('templates/navbar');
        $this->load->view('My_gallery', $data);
        $this->load->view('templates/footer');
    }

    public function Setting()
    {
        $data['user'] = $this->db->get_where('user', ['user_username' => $this->session->userdata('username')])->row_array();
        $data['title'] = "Gallery | Setting";
        $this->load->view('templates/header', $data);
        $this->load->view('templates/navbar');
        $this->load->view('Setting');
        $this->load->view('templates/footer');
    }

    public function kategori($kategoriID = NULL)
    {
        // Mendapatkan data pengguna berdasarkan session
        $data['user'] = $this->db->get_where('user', ['user_username' => $this->session->userdata('username')])->row_array();
        $data['album'] = $this->Model_helper->getAlbum();
        $data['kategori'] = $this->Model_helper->getKategori();
        $data['komentar'] = $this->Model_gallery->GetAllKomen();
        // ====== Pagination Configuration
        $config["base_url"] = base_url('User/kategori/' .$kategoriID);
        $config["total_rows"] = $this->Model_gallery->CountBykategori($kategoriID);
        $config["per_page"] = 6;
        $config["uri_segment"] = 4;
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close'] = '</span></li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close'] = '</span></li>';
        $config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close'] = '</span></li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close'] = '</span></li>';
        $this->pagination->initialize($config);
    
        // Mendapatkan data foto dengan menggunakan metode GetAllphoto dengan pagination
        $page = ($this->uri->segment(3)) ? $this->uri->segment(4) : 0;
        $data['foto'] = $this->Model_gallery->getAllPhotosbyKatgeori($config["per_page"], $page,$kategoriID);
        $data["links"] = $this->pagination->create_links();
        // ========
    
        $data['title'] = "Gallery | Searchphoto";
    
        $this->load->view('templates/header', $data);
        $this->load->view('templates/navbar');
        $this->load->view('kategori');
        $this->load->view('templates/footer');
    }
}
