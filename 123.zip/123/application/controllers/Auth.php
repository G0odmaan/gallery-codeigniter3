<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->helper('url');
		$this->load->model('Model_verifikasi');
		$this->load->model('Model_helper');
		$this->load->library('encryption');
		

	}

	public function registrasi()
	{
		$this->form_validation->set_rules('fullname', 'Fullname', 'required');
		$this->form_validation->set_rules('username', 'Username', 'required|min_length[5]|max_length[20]|is_unique[user.user_username]');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[user.user_email]');
		$this->form_validation->set_rules('address', 'Address', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

		if ($this->form_validation->run() == FALSE) {
			$data['title'] = "Gallery | registrasi";
			$this->load->view('templates/Auth_header', $data);
			$this->load->view('Auth/registrasi');
			$this->load->view('templates/Auth_footer');
		} else {
			$fullname = $this->input->post('fullname');
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$address = $this->input->post('address');
			$password =  password_hash($this->input->post('password'), PASSWORD_DEFAULT);
			$tanggal = date('Y-m-d H:i:s');

			$data = [
				'user_namalengkap' => $fullname,
				'user_username' => $username,
				'user_email' => $email,
				'user_alamat' => $address,
				'user_password' => $password,
				'user_tanggal' => $tanggal,

			];

			$this->Model_verifikasi->add_user($data);
			$this->session->set_flashdata('psn sukses', 'Registration successful!');
			redirect('Auth');
		}
	}

	public function login()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$user = $this->Model_verifikasi->Get_userByusername($username);

		if ($user) {
			if (password_verify($password, $user->user_password)) {
				$data = [
					'user_id' => $user->userID,
					'username' => $user->user_username,
					'email' => $user->user_email,
					'fullname' => $user->user_namalengkap,
					'biodata' => $user->user_biodata,
					'alamat' => $user->user_alamat,
				];


				$this->session->set_userdata($data);


				$cookie_data = [
					'name' => 'user_id',
					'value' => $user->userID,
					'expire' => 3600,
				];
				$this->input->set_cookie($cookie_data);

				// Redirect to Home after successful login
			$this->Model_helper->setpesan('psn sukses', 'Login successful!');
				redirect('Home');
			} else {
				$this->Model_helper->setpesan('login_error', 'Incorrect password');
			}
		} else {
			$this->Model_helper->setpesan('login_error', 'Incorrect username');
		}

		// Load the login view with flash messages
		$data['title'] = "Gallery | Login";
		$this->load->view('templates/Auth_header', $data);
		$this->load->view('Auth/login');
		$this->load->view('templates/Auth_footer');
	}

	public function logout()
	{
		$cookie_data = array(
			'name'   => 'user_id',
			'value'  => '',
			'expire' => time() - 3600,  // Set to a past time to expire the cookie
		);
		$this->input->set_cookie($cookie_data);
		$this->session->sess_destroy();
		$this->session->set_flashdata('psn_sukses', 'Logout success');
		redirect('Auth/login');
	}

	public function user_setting()
	{
		// Check if the form is submitted
		if ($this->input->post()) {
			// Initialize data with existing user settings
			$data = array(
				'user_namalengkap' => $this->input->post('fullname'),
				'user_username' => $this->input->post('username'),
				'user_email' => $this->input->post('email'),
				'user_alamat' => $this->input->post('alamat'),
				'user_biodata' => $this->input->post('biodata'),
				'user_aboutme' => $this->input->post('aboutme'),
			);
	
			// Process avatar file upload if available
			if (!empty($_FILES['avatar']['name'])) {
				$config['upload_path'] = 'dist/img/avatar';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['max_size'] = 2048; // 2MB max size, adjust as needed
				$config['encrypt_name'] = TRUE;
	
				$this->load->library('upload', $config);
	
				if ($this->upload->do_upload('avatar')) {
					// If file upload is successful, include the new avatar path in the data
					$upload_data = $this->upload->data();
					$data['user_avatar'] = $upload_data['file_name'];
	
					// Delete old avatar if it exists
					$old_avatar_path = $this->input->post('oldfile'); // Adjust this based on how you store the avatar path in the database
					if (!empty($old_avatar_path) && file_exists($old_avatar_path)) {
						unlink($old_avatar_path);
					}
				} else {
					// If file upload fails, display an error message
					$upload_error = $this->upload->display_errors();
					// Handle the error appropriately, for example, by displaying an error message to the user
					echo $upload_error;
					return;
				}
			} else {
				// Jika tidak ada file yang diunggah, hapus potensi avatar yang lama
				$old_avatar_path = $this->input->post('oldfile');
				if (!empty($old_avatar_path) && file_exists($old_avatar_path)) {
					unlink($old_avatar_path);
				}
	
				// Hapus field avatar dari data jika tidak ada file yang diunggah
				unset($data['user_avatar']);
			}
	
			// Check if any data has changed
			if ($this->Model_verifikasi->is_data_changed($data)) {
				// Update user settings in the database
				$user_id = $this->session->userdata('user_id');
				$this->Model_verifikasi->update_user($data, $user_id);
				$this->Model_helper->setpesan('update','Your data is updated!');
			}
	
			// Redirect to the same page for simplicity
			redirect('User/Setting');
		} else {
			// Form not submitted, load the user settings form view
			$data['error'] = $this->upload->display_errors(); // You need to define this method to get user data
			$this->load->view('Setting', $data);
		}
	}
	

}
