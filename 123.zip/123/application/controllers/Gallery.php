<?php

use PSpell\Config;

defined('BASEPATH') or exit('No direct script access allowed');

class Gallery extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('Model_verifikasi');
        $this->load->model('Model_gallery');
        $this->Model_verifikasi->checklogin();
        $this->load->model('Model_helper');
        $this->load->library('encryption');
    }

    public function upload()
    {
        $this->form_validation->set_rules('judul', 'Judul', 'required|trim');
        $this->form_validation->set_rules('album', 'Album', 'trim');
        $this->form_validation->set_rules('kategori', 'Kategori', 'trim');
        $this->form_validation->set_rules('deskripsi', 'Judul', 'required|trim');

        $config['upload_path']    = 'dist/img/foto/';
        $config['allowed_types']  = 'gif|jpg|png|jpeg';
        $config['max_size']       = '2048'; // 2MB
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);

        if ($this->form_validation->run() == FALSE) {
            redirect('User/searcphoto');
        } else {
            $judul = $this->input->post('judul');
            $album = $this->input->post('album');
            $kategori = $this->input->post('kategori');
            $deskripsi = $this->input->post('deskripsi');
            $tanggal = date('Y-m-d H:i:s');
            $user = $this->session->userdata('user_id');

            if (!$this->upload->do_upload('foto')) {
                $this->Model_helper->$this->Model_helper->setpesan('upload_gagal', 'Gambar anda gagal di upload!');
                redirect('User/searchphoto');

                return;
            } else {
                $img = $this->upload->data();
                $data = [
                    'foto_judul' => $judul,
                    'foto_deskripsi' => $deskripsi,
                    'kategoriID' => $kategori,
                    'foto_tanggal' => $tanggal,
                    'foto_lokasi' => $img['file_name'],
                    'albumId' => $album,
                    'userID' => $user,
                ];

                $this->Model_gallery->insert_image($data, 'foto');
                $this->Model_helper->setpesan('upload_sukses', 'Gambar anda berhasil di upload!');
                redirect('User/searchphoto');
            }
        }
    }

    public function upload_album()
    {
        $this->form_validation->set_rules('judul', 'Judul', 'required|trim');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required|trim');
        if ($this->form_validation->run() == FALSE) {
            redirect('User/album_page');
        } else {
            $data = [
                'album_nama' => $this->input->post('judul'),
                'album_deskripsi' => $this->input->post('deskripsi'),
                'album_tanggal' => date('Y-m-d H:i:s'),
                'userID' => $this->session->userdata('user_id'),
            ];

            $this->Model_gallery->insert_album($data);
            $this->Model_helper->setpesan('album_sukses', 'album anda berhasil di upload!');
            redirect('User/album_page');
        }
    }

    public function form_komen()
    {
        $komentar = $this->input->post('komentar');
        $user = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $foto = $this->input->post('fotoID');


        if (!$komentar) {
            $this->Model_helper->setpesan('error komen', 'komentar tidak boleh kosong');
            redirect('User/searchphoto');
        } else {
            $data = [
                'fotoID' => $foto,
                'userID' => $user,
                'komentar_isi' => $komentar,
                'komentar_tanggal' => $tanggal,
            ];

            $this->Model_gallery->insert_komen($data, 'komentar');
            $this->Model_helper->setpesan('sukses_komen', 'komentar sukses');
            redirect('User/searchphoto');
        }
    }

    public function delete_komen($komentarID, $fotoID)
    {
        $userID = $this->session->userdata('user_id');
        // Periksa apakah userID yang menghapus komentar sesuai dengan userID pada foto
        if ($this->Model_verifikasi->GetuserID_foto($fotoID, $userID) !== null) {
            // Hapus komentar
            $this->db->where('komentarID', $komentarID);
            $this->db->delete('komentar');

            if ($this->db->affected_rows() > 0) {
                redirect('User/searchphoto');
            }
        } else {
            // User tidak memiliki izin untuk menghapus komentar
            return false;
        }
    }

    public function delete_img($fotoID)
    {
        $userID = $this->session->userdata('user_id');

        // Pastikan pengguna memiliki hak akses
        if ($this->Model_verifikasi->GetuserID_foto($fotoID, $userID) !== null) {
            // Hapus data dari tabel foto, komentar, dan likefoto
            // Hapus komentar terkait dengan foto
            $this->db->where('fotoID', $fotoID);
            $this->db->delete('komentar');

            // Hapus likefoto terkait dengan foto
            $this->db->where('fotoID', $fotoID);
            $this->db->delete('likefoto');

            // Hapus data dari tabel foto
            $this->db->where('fotoID', $fotoID);
            $this->db->delete('foto');

            // Periksa apakah ada baris yang terpengaruh oleh operasi penghapusan
            if ($this->db->affected_rows() > 0) {
                $this->Model_helper->setpesan('delete_img', 'Your image has been successfully deleted');
            } else {
                $this->Model_helper->setpesan('delete_img', 'Failed to delete the image. Please try again later.', 'error');
            }

            // Redirect ke halaman galeri
            redirect('User/my_gallery/' . $userID);
            exit(); // tambahkan pernyataan exit() untuk memastikan tidak ada kode yang dijalankan setelah redirect
        } else {
            // Pengguna tidak memiliki hak akses untuk menghapus gambar
            return false;
        }
    }

    public function like_photo($fotoID)
    {
        $userID = $this->session->userdata('user_id');

        // Periksa apakah user telah melakukan like sebelumnya
        $oldlike = $this->db->get_where('likefoto', array('fotoID' => $fotoID, 'userID' => $userID))->row();

        if ($oldlike) {
            // Jika like sudah ada, hapus like (toggle off)
            $this->db->where('likeID', $oldlike->likeID);
            $this->db->delete('likefoto');
        } else {
            // Jika belum ada like, tambahkan like (toggle on)
            $data = [
                'fotoID' => $fotoID,
                'userID' => $userID,
                // Tambahkan kolom dan nilai lain yang mungkin dibutuhkan
            ];

            $this->db->insert('likefoto', $data);
        }

        // Redirect kembali ke halaman foto atau halaman lainnya
        redirect('User/searchphoto');
    }

    public function delete_album($albumID)
    {
        $userID = $this->session->userdata('user_id');
    
        // Asumsi Model_verifikasi memiliki metode GetuserID_album
        if ($this->Model_verifikasi->GetuserID_album($albumID, $userID) !== null) {
            // Dapatkan ID foto yang terkait dengan album
            $fotoIDs = $this->Model_gallery->gefotoByalbum($albumID);
    
            // Hapus komentar dan likefoto terkait dengan setiap foto
            foreach ($fotoIDs as $fotoID) {
                $this->db->where('fotoID', $fotoID);
                $this->db->delete('komentar');
                
                $this->db->where('fotoID', $fotoID);
                $this->db->delete('likefoto');
            }
    
            // Sekarang, hapus album
            $this->db->where('albumID', $albumID);
            $this->db->delete('album');
    
            if ($this->db->affected_rows() > 0) {
                $this->Model_helper->setpesan('delete_album', 'Album Anda berhasil dihapus');
            } else {
                $this->Model_helper->setpesan('delete_album_gagal', 'Album Anda gagal dihapus');
            }
    
            // Redirect ke halaman galeri pengguna
            redirect('User/my_gallery/' . $userID);
            exit(); // Tambahkan exit() untuk memastikan tidak ada kode yang dijalankan setelah redirect
        } else {
            // Pengguna tidak memiliki izin untuk menghapus album
            return false;
        }
    }
    
}
