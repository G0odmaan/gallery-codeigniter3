<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->helper('url');
		$this->load->model('Model_verifikasi');
		$this->load->model('Model_gallery');
        // $this->Model_verifikasi->checklogin();
		$this->load->library('encryption');
       
	}

    public function index()
	{
		$data['user'] = $this->db->get_where('user',['user_username' => $this->session->userdata('username')])->row_array();
		$data['title'] = "Gallery | Home";
		$data['foto'] = $this->Model_gallery->getPhotosByLikes();
		$this->load->view('templates/header', $data);
        $this->load->view('templates/navbar');
		$this->load->view('index');
		$this->load->view('templates/footer');
	}

    public function searchphoto()
    {
        $data['title'] = "Gallery | Searchphoto";
        $this->load->view('templates/header', $data);
        $this->load->view('templates/navbar');
		$this->load->view('searchphoto');
		$this->load->view('templates/footer');
    }

	public function policy()
	{
		$data['title'] = "Gallery | Policy";
        $this->load->view('templates/header', $data);
		$this->load->view('Policy');
		$this->load->view('templates/footer');

	}








}
