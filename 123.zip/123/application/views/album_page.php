<div class="page-wrapper">
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <ul class="nav nav-bordered mb-4">
                <li class="nav-item">
                    <a class="nav-link  " aria-current="page" href="<?= base_url('User/searchphoto') ?>">Image</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?= base_url('User/album_page') ?>">Album</a>
                </li>
            </ul>
            <div class="row g-2 align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        Gallery
                    </h2>
                    <div class="text-muted mt-1">something new in here</div>

                    <?= $this->Model_helper->showpesan('album_sukses', 'success'); ?>
                </div>
                <!-- Page title actions -->
                <div class="col-auto ms-auto d-print-none">
                    <div class="d-flex">
                        <div class="me-3">
                            <div class="input-icon">
                                <input type="text" value="" class="form-control" placeholder="Search…">
                                <span class="input-icon-addon">
                                    <!-- Download SVG icon from http://tabler-icons.io/i/search -->
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                        <path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" />
                                        <path d="M21 21l-6 -6" />
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M12 5l0 14" />
                                <path d="M5 12l14 0" />
                            </svg>
                            Add Album
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <div class="row">
                <div class="col-12 col-md-6 col-lg">
                    <div class="mb-4">
                        <div class="row row-cards">
                            <?php foreach ($album as $row) : ?>
                                <div class="col-4">
                                    <div class="card card-sm">
                                        <div class="card-body">
                                            <h3 class="card-title"><a href=""><?= $row->album_nama ?></a></h3>

                                            <div class="avatar-list avatar-list-stacked">
                                                <?php for ($i = 0; $i < $row->jumlah_foto; $i++) : ?>
                                                    <?php
                                                    $fotoID = $this->Model_gallery->GetFotoID($row->albumID, $i);
                                                    $foto_lokasi = $this->Model_gallery->GetFotoLokasi($fotoID);
                                                    ?>
                                                    <img src="<?= base_url('dist/img/foto/' . $foto_lokasi) ?>" class="avatar avatar-xl rounded" alt="Foto Album">
                                                <?php endfor; ?>
                                            </div>

                                            <div class="mt-4">
                                                <div class="row">
                                                    <div class="col">
                                                        <div>
                                                            <div></div>
                                                            <div><?= $row->user_namalengkap ?></div>
                                                            <div class="text-muted small"><?= $row->album_tanggal  ?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

            </div>

            <div class="d-flex justify-content-end mt-4">
                <ul class="pagination">
                    <?= $links; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- modals add image -->
    <?= form_open_multipart(site_url('Gallery/upload_album')) ?>
    <div class="modal modal-blur fade   " id="exampleModal" tabindex="-1">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">File Name</label>
                                <input name="judul" id="judul" type="text" class="form-control">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div>
                                    <label class="form-label">Description</label>
                                    <textarea name="deskripsi" id="deskripsi" class="form-control" data-bs-toggle="autosize" placeholder="Type something…"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal">
                            Cancel
                        </a>
                        <!-- Tombol submit hanya muncul jika tidak ada pesan kesalahan validasi -->
                        <button name="submit" type="submit" class="btn btn-primary">Create Now</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?= form_close(); ?>