    <div class="page-wrapper">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
            <ul class="nav nav-bordered mb-4">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?= base_url('User/searchphoto') ?>">Image</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?= base_url('User/album_page') ?>">Album</a>
              </li>
            </ul>
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <h2 class="page-title">
                            Gallery
                        </h2>
                        <div class="text-muted mt-1">something new in here</div>

                        <?=  $this->Model_helper->showpesan('upload_sukses', 'success'); ?>
                        <?=  $this->Model_helper->showpesan('upload_gagal', 'warning'); ?>
                        <?=  $this->Model_helper->showpesan('error komen', 'danger'); ?>
                    </div>
                    <!-- Page title actions -->
                    <div class="col-auto ms-auto d-print-none">
                        <div class="d-flex">
                            <div class="me-3">
                                <div class="input-icon">
                                    <input type="text" value="" class="form-control" placeholder="Search…">
                                    <span class="input-icon-addon">
                                        <!-- Download SVG icon from http://tabler-icons.io/i/search -->
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                            <path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" />
                                            <path d="M21 21l-6 -6" />
                                        </svg>
                                    </span>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <path d="M12 5l0 14" />
                                    <path d="M5 12l14 0" />
                                </svg>
                                Add Image
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page body -->
        <div class="page-body">
            <div class="container-xl">
                <div class="row row-cards">
                    <?php foreach ($foto as $rows) : ?>
                        <div class="col-sm-3 col-lg-4">
                            <div class="card card-sm">
                                <a data-bs-toggle="modal" data-bs-target="#modal-full-width-<?= $rows->fotoID; ?>" href="#" class="d-block">
                                    <img src="<?= base_url('dist/img/foto/' . $rows->foto_lokasi); ?>" width="200" height="250" class=" glightbox card-img-top card-link-pop">
                                </a>
                                <div class="card-body">
                                    <div class="d-flex align-items-center">
                                        <div>
                                            <div><?= $rows->user_namalengkap ?></div>
                                            <div class="text-muted small"><?= $rows->foto_tanggal  ?></div>
                                        </div>
                                        <div class="ms-8">
                                            <a href="#" class="text-muted">
                                                <!-- Download SVG icon from http://tabler-icons.io/i/eye -->
                                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-message-circle-2" width="24" height="20" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                    <path d="M3 20l1.3 -3.9a9 8 0 1 1 3.4 2.9l-4.7 1" />
                                                </svg> <?= $rows->jumlah_komentar ?>
                                            </a>
                                            <a href="<?= base_url('Gallery/like_photo/' . $rows->fotoID) ?>" class="ms-1 text-muted">
                                                <!-- Download SVG icon from http://tabler-icons.io/i/heart -->
                                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="20" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                    <path d="M19.5 12.572l-7.5 7.428l-7.5 -7.428a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.572" />
                                                </svg>
                                                <?= $rows->jumlah_like ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="d-flex justify-content-end mt-4">
                    <ul class="pagination">
                        <?= $links; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- modals add image -->
        <?= form_open_multipart(site_url('Gallery/upload')) ?>
        <div class="modal modal-blur fade   " id="exampleModal" tabindex="-1">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label">File Name</label>
                                    <input name="judul" id="judul" type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label class="form-label">Upload File</label>
                                    <input name="foto" type="file" class="form-control" />
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <!-- membuat album dinamis -->
                                    <label class="form-label">Albums</label>
                                    <?php if ($album) : ?>
                                        <select name="album" class="form-select" id="select-albums">
                                            <?php foreach ($album as $row) : ?>
                                                <option value="<?= $row->albumID ?>"><?= $row->album_nama ?> </option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php else : ?>
                                        <select name="album" class="form-select" id="select-albums">
                                            <option value=""></option>
                                        </select>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <!-- membuat kategori dinamis -->
                                    <label class="form-label">Categories</label>
                                    <?php if ($kategori) : ?>
                                        <select name="kategori" class="form-select" id="select-categories">
                                            <?php foreach ($kategori as $raw) : ?>
                                                <option value="<?= $raw->kategoriID ?>"><?= $raw->kategori_nama ?> </option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php else : ?>
                                        <select name="album" class="form-select" id="select-albums">
                                            <option value=""></option>
                                        </select>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div>
                                        <label class="form-label">Description</label>
                                        <textarea name="deskripsi" id="deskripsi" class="form-control" data-bs-toggle="autosize" placeholder="Type something…"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal">
                                Cancel
                            </a>
                            <!-- Tombol submit hanya muncul jika tidak ada pesan kesalahan validasi -->
                            <button name="submit" type="submit" class="btn btn-primary">Create Now</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?= form_close(); ?>

        <!-- modal view image-->
        <?php $index = 0; ?>
        <?php while ($index < count($foto)) : ?>
            <?php $row = $foto[$index]; ?>
            <div class="modal modal-blur fade" id="modal-full-width-<?= $row->fotoID; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-full-width modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <!-- Isi modal disesuaikan dengan kontennya -->
                            <!-- Misalnya: -->
                            <div class="row">
                                <div class="col-sm-4">
                                    <p class="sm-4"></p>
                                    <img class="" width="500" height="300" src="<?= base_url('dist/img/foto/' . $row->foto_lokasi); ?>">
                                    <p class="sm-4"></p>
                                    <div class="card-body">
                                        <div class="tab-content">
                                            <div class="tab-pane active show" id="tabs-home-1">
                                                <h4><?= $row->foto_judul; ?></h4>
                                                <div><?= $row->foto_deskripsi; ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="card">
                                        <div class="position-relative">
                                            <div class="position-absolute top-0 left-0 px-3 mt-1 w-75">
                                                <div class="row g-2">
                                                    <div class="col-auto">
                                                    </div>
                                                    <div class="col">
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="chart-development-activity"></div>
                                        </div>
                                        <div class="col-12">
                                            <div class="card" style="height: 20rem">
                                                <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                                                    <div class="divide-y">
                                                        <?php foreach ($komentar as $raw) : ?>
                                                            <?php if ($raw->fotoID == $row->fotoID) : ?>
                                                                <div class="row">
                                                                    <div class="col-auto">
                                                                        <span class="avatar avatar-sm">
                                                                            <img src="<?= base_url('dist/img/avatar/' . $raw->user_avatar) ?>" alt="Profil Image">
                                                                        </span>
                                                                    </div>
                                                                    <div class="col">
                                                                        <div class="text-truncate">
                                                                            <strong><?= $raw->user_username ?></strong>
                                                                            <div></div>
                                                                            <?= $raw->komentar_isi ?></strong>.
                                                                        </div>
                                                                        <div class="text-muted small"><?= $raw->komentar_tanggal ?></div>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <div class="dropdown ms-5">
                                                                            <a href="#" class="btn-action dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><!-- Download SVG icon from http://tabler-icons.io/i/dots-vertical -->
                                                                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                                                    <path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                                                                                    <path d="M12 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                                                                                    <path d="M12 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                                                                                </svg>
                                                                            </a>
                                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                                <a class="dropdown-item text-danger" href="<?= base_url('Gallery/delete_komen/' . $raw->komentarID . '/' . $raw->fotoID) ?>">Delete comment</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="mb-3"></div>
                                    <?= form_open_multipart(site_url('Gallery/form_komen')); ?>
                                    <div class="mb-3">
                                        <div class="input-group mb-2">
                                            <input type="hidden" name="fotoID" value="<?= $row->fotoID ?>">
                                            <input name="komentar" type="text" class="form-control" placeholder="comment">
                                            <button class="btn" type="submit" name="submit">send</button>
                                        </div>
                                    </div>
                                    <?= form_close(); ?>
                                </div>
                            </div>

                            <!-- ... -->
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn " data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php $index++; ?>
        <?php endwhile; ?>