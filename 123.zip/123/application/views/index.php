<div class="page-wrapper">
  <!-- Page header -->
  <!-- Page body -->
  <div class="page-body">
    <div class="container-xl">
      <!-- Content here -->
      <main>


        <section class="py-5 text-center container">
          <div class="row py-lg-5">
            <div class="col-lg-6 col-md-8 mx-auto">
              <h1 class="fw-light">Hallo selamat datang Buttack'S</h1>
              <p class="lead text-muted">Buttacks adalah website Gallery tempat dimana berbagi inspirasi dan kenangan yang dituang dalam seni gambar yang bisa diakses banyak orang.</p>
              <p>
                <a href="<?= base_url('User/Searchphoto') ?>" class="btn btn-primary my-2">Eksplore Sekarang
                </a>
              </p>
            </div>
          </div>
        </section>
        <h2 class="featurette-heading">Most Popular Post</h2>
        <div class="album py-5 bg-light">
          <div class="container">
            

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <?php  foreach($foto as $row ) : ?>
              <div class="col">
                <div class="card shadow-sm">
                <img src="<?= base_url('dist/img/foto/' . $row->foto_lokasi) ?>" width="200" height="250" class="card-img-top" alt="Image">
                  <div class="card-body">
                    <p class="card-text"><?= $row->foto_judul ?>.</p>
                    <div class="d-flex justify-content-between align-items-center">
                    <p class="card-text"><?= $row->foto_deskripsi ?>.</p>

                      <div class="btn-group">
                      </div>
                      <small class="text-muted"><?= $row->foto_tanggal ?></small>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach;?>
            </div>
          </div>
        </div>

        <div class="container marketing">
        <h2 class="featurette-heading mt-4">First featurette heading. <span class="text-muted">It’ll blow your mind.</span></h2>

          

          <!-- Three columns of text below the carousel -->
          <div class="row mt-4">
            <div class="col-lg-4">
            <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false">
                <title>Placeholder</title>
                <rect width="100%" height="100%" fill="#777" /><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text>
              </svg>

              <h2>Heading</h2>
              <p>Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>
              <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
              <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false">
                <title>Placeholder</title>
                <rect width="100%" height="100%" fill="#777" /><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text>
              </svg>

              <h2>Heading</h2>
              <p>Another exciting bit of representative placeholder content. This time, we've moved on to the second column.</p>
              <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
              <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false">
                <title>Placeholder</title>
                <rect width="100%" height="100%" fill="#777" /><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text>
              </svg>

              <h2>Heading</h2>
              <p>And lastly this, the third column of representative placeholder content.</p>
              <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
            </div><!-- /.col-lg-4 -->
          </div><!-- /.row -->


          <!-- START THE FEATURETTES -->

          <hr class="featurette-divider">
          <h2 class="featurette-heading">First featurette heading. <span class="text-muted">It’ll blow your mind.</span></h2>


          <div class="row featurette mt-5">
            <div class="col-md-7">
              <p class="lead">Some great placeholder content for the first featurette here. Imagine some exciting prose here.</p>
            </div>
            <div class="col-md-5">
            <img src="<?= base_url('dist/img/foto/gambar1.png') ?>" width="350" height="350" class="card-img-top" alt="Image">


            </div>
          </div>

          <hr class="featurette-divider">
          

          <div class="row featurette">
            <div class="col-md-7 order-md-2">
              <h2 class="featurette-heading">Oh yeah, it’s that good. <span class="text-muted">See for yourself.</span></h2>
              <p class="lead">Another featurette? Of course. More placeholder content here to give you an idea of how this layout would work with some actual real-world content in place.</p>
            </div>
            <div class="col-md-5 order-md-1">
            <img src="<?= base_url('dist/img/foto/gambar2.png') ?>" width="350" height="350" class="card-img-top" alt="Image">


            </div>
          </div>

          <hr class="featurette-divider">

          <div class="row featurette">
            <div class="col-md-7">
              <h2 class="featurette-heading">And lastly, this one. <span class="text-muted">Checkmate.</span></h2>
              <p class="lead">And yes, this is the last block of representative placeholder content. Again, not really intended to be actually read, simply here to give you a better view of what this would look like with some actual content. Your content.</p>
            </div>
            <div class="col-md-5">
            <img src="<?= base_url('dist/img/foto/gambar3.png') ?>" width="350" height="350" class="card-img-top" alt="Image">


            </div>
          </div>

          <hr class="featurette-divider">

          <!-- /END THE FEATURETTES -->

        </div><!-- /.container -->

      </main>

    </div>
  </div>