<div class="page-wrapper">
  <div class="page-header">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-auto">
          <span class="avatar avatar-lg rounded" style="background-image: url(<?= base_url('dist/img/avatar/' . $user['user_avatar']) ?>)"></span>
        </div>
        <div class="col">
          <h1 class="fw-bold"><?= $user['user_namalengkap'] ?></h1>
          <div class="my-2"><?= $user['user_biodata'] ?>
          </div>
          <div class="list-inline list-inline-dots text-muted">
            <div class="list-inline-item">
              <!-- Download SVG icon from http://tabler-icons.io/i/map -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-inline" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M3 7l6 -3l6 3l6 -3l0 13l-6 3l-6 -3l-6 3l0 -13" />
                <path d="M9 4l0 13" />
                <path d="M15 7l0 13" />
              </svg>
              <?= $user['user_alamat'] ?>
            </div>
            <div class="list-inline-item">
              <!-- Download SVG icon from http://tabler-icons.io/i/mail -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-inline" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M3 7a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v10a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-10z" />
                <path d="M3 7l9 6l9 -6" />
              </svg>
              <a href="#" class="text-reset"><?= $user['user_email'] ?></a>
            </div>
            <div class="list-inline-item">
              <!-- Download SVG icon from http://tabler-icons.io/i/cake -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-calendar-due" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M4 5m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z" />
                <path d="M16 3v4" />
                <path d="M8 3v4" />
                <path d="M4 11h16" />
                <path d="M12 16m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
              </svg>
              <?= $user['user_tanggal'] ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?=  $this->Model_helper->showpesan('delete_img', 'success'); ?>
  <!-- Page body -->
  <div class="page-body">
    <div class="container-xl">
      <div class="row g-3">
        <div class="col-8">
          <div class="card mb-5">
            <div class="card-header">
              <h3 class="card-title">My Photos</h3>
            </div>
            <div class="list-group list-group-flush overflow-auto" style="max-height: 25rem">
              <?php foreach ($foto as  $row) : ?>
                <div class="list-group-item">
                  <div class="row">
                    <div class="col-auto">
                      <a href="#">
                        <span class="avatar" style="background-image: url(<?= base_url('dist/img/foto/' . $row->foto_lokasi) ?>)"></span>
                      </a>
                    </div>
                    <div class="col text-truncate">
                      <a href="#" class="text-body d-block"><?= $row->foto_judul ?></a>
                      <div class="text-muted text-truncate mt-n1"><?= $row->foto_tanggal ?></div>
                    </div>
                    <div class="col-auto">
                      <div class="dropdown ms-5">
                        <a href="#" class="btn-action dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><!-- Download SVG icon from http://tabler-icons.io/i/dots-vertical -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                            <path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                            <path d="M12 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                            <path d="M12 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                          </svg>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                        <a class="dropdown-item text-danger" href="<?= base_url('Gallery/delete_img/' . $row->fotoID) ?>" onclick="return confirm('Are you sure you want to delete this image?')">Delete</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">My Albums</h3>
            </div>
            <div class="list-group list-group-flush overflow-auto" style="max-height: 30rem">
            <?php foreach($album as $raw ) {?>
              <div class="list-group-item">
                <div class="row">
                  <div class="col-auto">
                    <a href="#">
                      <span class="avatar" style="background-image: url(<?= base_url('dist/img/avatar/' .$raw->user_avatar)  ?>)"></span>
                    </a>
                  </div>
                  <div class="col text-truncate">
                    <a href="#" class="text-body d-block"><?= $raw->album_nama ?></a>
                    <div class="text-muted text-truncate mt-n1"><?= $raw->album_deskripsi ?></div>
                  </div>
                  <div class="col-auto">
                      <div class="dropdown ms-5">
                        <a href="#" class="btn-action dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><!-- Download SVG icon from http://tabler-icons.io/i/dots-vertical -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                            <path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                            <path d="M12 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                            <path d="M12 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
                          </svg>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                        <a class="dropdown-item text-danger" href="<?= base_url('Gallery/delete_album/' . $raw->albumID) ?>" onclick="return confirm('Are you sure you want to delete this image?')">Delete</a>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
              <?php  }?>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="row row-cards">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div class="card-title">Basic info</div>
                  <!-- <div class="mb-2">
                      <svg xmlns="http://www.w3.org/2000/svg" class="icon me-2 text-muted" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                      <path d="M3 7m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z" />
                      <path d="M8 7v-2a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v2" />
                      <path d="M12 12l0 .01" />
                      <path d="M3 13a20 20 0 0 0 18 0" />
                    </svg>
                    Worked at: <strong>Devpulse</strong>
                  </div> -->
                  <div class="mb-2">
                    <!-- Download SVG icon from http://tabler-icons.io/i/home -->
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon me-2 text-muted" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                      <path d="M5 12l-2 0l9 -9l9 9l-2 0" />
                      <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" />
                      <path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" />
                    </svg>
                    Lives in: <strong><?= $user['user_alamat'] ?></strong>
                  </div>
                  <div class="mb-2">
                    <!-- Download SVG icon from http://tabler-icons.io/i/map-pin -->
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon me-2 text-muted" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                      <path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" />
                      <path d="M17.657 16.657l-4.243 4.243a2 2 0 0 1 -2.827 0l-4.244 -4.243a8 8 0 1 1 11.314 0z" />
                    </svg>
                    From: <strong><span class="flag flag-country-id"></span>
                      Indonesia</strong>
                  </div>
                  <div class="mb-2">
                    <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon me-2 text-muted" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                      <path d="M4 7a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12z" />
                      <path d="M16 3v4" />
                      <path d="M8 3v4" />
                      <path d="M4 11h16" />
                      <path d="M11 15h1" />
                      <path d="M12 15v3" />
                    </svg>
                    Join date: <strong><?= $user['user_tanggal'] ?></strong>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <h2 class="card-title">About Me</h2>
                  <div>
                    <p>
                      <?= $user['user_aboutme'] ?>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>