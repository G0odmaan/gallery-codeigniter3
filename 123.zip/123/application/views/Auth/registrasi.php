<script src="./dist/js/demo-theme.min.js?1684106062"></script>
<div class="page page-center">
    <div class="container container-tight py-4">
        <div class="text-center mb-4">
            <a href="." class="navbar-brand navbar-brand-autodark"><img src="<?= base_url('static/logo.svg') ?>" height="100" alt=""></a>
        </div>
        <?= form_open_multipart('Auth/registrasi', 'class="card card-md" autocomplete="off" novalidate'); ?>
        <div class="card-body">
            <h2 class="card-title text-center mb-4">Create new account</h2>

            <div class="col-lg-12 mb-3">
                <label class="form-label">Fullname</label>
                <input type="text" class="form-control" name="fullname" placeholder="Enter name">
                <?= form_error('fullname', '<div class="text-danger">', '</div>'); ?>
            </div>

            <div class="row">
                <div class="col-lg-6 mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" class="form-control" name="username" placeholder="Enter username">
                    <?= form_error('username', '<div class="text-danger">', '</div>'); ?>
                </div>

                <div class="col-lg-6 mb-3">
                    <label class="form-label">Email address</label>
                    <input type="email" class="form-control" name="email" placeholder="Enter email">
                    <?= form_error('email', '<div class="text-danger">', '</div>'); ?>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Address</label>
                <textarea class="form-control" name="address" data-bs-toggle="autosize" placeholder="Place Address"></textarea>
                <?= form_error('address', '<div class="text-danger">', '</div>'); ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <div class="input-group input-group-flat">
                    <input type="password" class="form-control" name="password" placeholder="Password" autocomplete="off">
                    <?= form_error('password', '<div class="text-danger">', '</div>'); ?>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Confirm Password</label>
                <div class="input-group input-group-flat">
                    <input type="password" class="form-control" name="confirm_password" placeholder="Password" autocomplete="off">
                    <?= form_error('confirm_password', '<div class="text-danger">', '</div>'); ?>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-check">
                    <input type="checkbox" class="form-check-input" name="agree_terms">
                    <span class="form-check-label">Agree to the <a href="<?= base_url('Home/policy') ?>" tabindex="-1">terms and policy</a>.</span>
                </label>
            </div>

            <div class="form-footer">
                <button type="submit" class="btn btn-primary w-100">Create new account</button>
            </div>
        </div>
        <?= form_close(); ?>

        <div class="text-center text-muted mt-3">
            Already have account? <a href="./sign-in.html" tabindex="-1">Sign in</a>
        </div>
    </div>
</div>