    <!-- Libs JS -->
    <!-- Tabler Core -->
    <script src="<?= base_url('/dist/js/tabler.min.js?1684106062') ?>" defer></script>
    <script src="<?= base_url('/dist/js/demo.min.js?1684106062') ?>" defer></script>
  </body>
</html>