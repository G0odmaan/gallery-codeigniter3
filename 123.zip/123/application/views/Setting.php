<div class="page-wrapper">
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        Account Settings
                    </h2>
                    
                    <div class="text-muted mt-1"><?=  $this->Model_helper->showpesan('update','success') ?></div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="row g-0">
                    <div class="col-3 d-none d-md-block border-end">
                        <div class="card-body">
                            <h4 class="subheader">Profile settings</h4>
                            <div class="list-group list-group-transparent">
                                <a href="<?= base_url('User/Setting') ?>" class="list-group-item list-group-item-action d-flex align-items-center active">My Account</a>
                            </div>
                        </div>
                    </div>
                    <div class="col d-flex flex-column">
                        <?= form_open_multipart(site_url('Auth/user_setting'),'enctype="multipart/form-data"'); ?>
                        <div class="card-body">
                            <h2 class="mb-4">My Account</h2>
                            <h3 class="card-title">Profile Details</h3>
                            <div class="row align-items-center">
                                <div class="col-auto"><span  class="avatar avatar-xl" style="background-image: url(<?= base_url('dist/img/avatar/' . $user['user_avatar']) ?>)"></span>
                                </div>
                                <div class="col-auto">
                                    <div class="form-label">Select Avatar</div>
                                    <input name="avatar" type="file" class="form-control" />
                                    <input type="hidden" name="oldfile" value="<?=  base_url('dist/img/avatar/' . $user['user_avatar'])  ?>" >
                                </div>
                                <div class="col-auto" ><a href="#" class="btn btn-ghost-danger">
                                        Delete avatar
                                    </a></div>
                            </div>
                            <h3 class="card-title mt-4">Setting Profile</h3>
                            <div class="row g-3">
                                <div class="col-md">
                                    <div class="form-label">Fullname</div>
                                    <input name="fullname" type="text" class="form-control" value="<?= $user['user_namalengkap'] ?>">
                                </div>
                                <div class="col-md">
                                    <div class="form-label">Username</div>
                                    <input name="username" type="text" class="form-control" value="<?= $user['user_username']; ?>">
                                </div>
                                <div class="col-md">
                                    <div class="form-label">Bio Data</div>
                                    <input name="biodata" type="text" class="form-control" value="<?= $user['user_biodata']; ?>">
                                </div>
                            </div>
                            <div class="row g-3 mt-3">
                                <div class="col-md">
                                    <div class="form-label">Location</div>
                                    <textarea name="alamat" class="form-control" data-bs-toggle="autosize"  placeholder=""><?= $user['user_alamat']; ?></textarea>
                                </div>
                                <div class="col-md">
                                    <label class="form-label">About Me</label>
                                    <textarea name="aboutme" class="form-control" data-bs-toggle="autosize" placeholder=""><?= $user['user_aboutme']; ?></textarea>
                                </div>
                            </div>
                            <h3 class="card-title mt-4">Email</h3>
                            <p class="card-subtitle">This contact will be shown to others publicly, so choose it carefully.</p>
                            <div>
                                <div class="row g-2">
                                    <div class="col-auto">
                                        <input name="email" type="email" class="form-control w-auto" value="<?= $user['user_email']; ?>">
                                    </div>
                                </div>
                            </div>
                            <h3 class="card-title mt-4">Password</h3>
                            <p class="card-subtitle">You can set a permanent password if you don't want to use temporary login codes.</p>
                            <div>
                                <a class="btn" data-bs-toggle="modal" data-bs-target="#modal-team" type="button">
                                    Set new password
                                </a>
                            </div>

                            <div class="card-footer bg-transparent mt-auto">
                                <div class="btn-list justify-content-end">
                                    <button href="#" class="btn btn-primary">
                                        Change
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?= form_close(); ?>
                    </div>
                </div>
            </div>
        </div <!-- modal password reset -->
        <form action="http://localhost/code3/Ctrl_setting/setpassword" enctype="multipart/form-data" method="post" accept-charset="utf-8">
            <div class="modal modal-blur fade" id="modal-team" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Set New Password</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row mb-3 align-items-end">
                                <div class="col-12">
                                    <label class="form-label">old password</label>
                                    <input name="old_password" id="password" type="password" class="form-control" />
                                </div>
                                <div class="col">
                                    <label class="form-label">new password</label>
                                    <input name="new_password" id="password2" type="password" class="form-control" />
                                </div>
                                <div class="col">
                                    <label class="form-label">confirmation new password</label>
                                    <input name="new_password2" id="password2" type="password" class="form-control" />
                                </div>

                            </div>
                            <div>
                                <div class="card-footer bg-transparent mt-auto">
                                    <div class="btn-list justify-content-end">
                                        <button name="submit" id="submit" type="submit" class="btn btn-primary">
                                            Submit
                                        </button>
                                    </div>
                                </div>
        </form>