-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Mar 2024 pada 20.45
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `daniel_ukk`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `albumID` int(25) NOT NULL,
  `album_nama` varchar(255) NOT NULL,
  `album_deskripsi` text NOT NULL,
  `album_tanggal` date NOT NULL,
  `userID` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `fotoID` int(25) NOT NULL,
  `foto_judul` varchar(255) NOT NULL,
  `foto_deskripsi` text NOT NULL,
  `kategoriID` int(25) NOT NULL,
  `foto_tanggal` date NOT NULL,
  `foto_lokasi` varchar(255) NOT NULL,
  `albumID` int(25) NOT NULL,
  `userID` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `foto`
--

INSERT INTO `foto` (`fotoID`, `foto_judul`, `foto_deskripsi`, `kategoriID`, `foto_tanggal`, `foto_lokasi`, `albumID`, `userID`) VALUES
(36, 'ini adalah amerikadadad', 'aadada', 1, '2024-03-05', '85dbf15812e2f6a76f2102428a4ea51a.jpg', 2, 4),
(42, 'daniel ganteng', 'adadaadadadadad', 1, '2024-03-05', '10f2f5a2fe78a138a72f7ec94fcf84d4.jpg', 3, 3),
(43, 'dqqefefe', 'adadw', 1, '2024-03-05', '983111d5c90247644176ce88788ba637.png', 2, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `kategoriID` int(25) NOT NULL,
  `kategori_nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`kategoriID`, `kategori_nama`) VALUES
(1, 'otomotif'),
(2, 'olahraga'),
(3, 'keluarga'),
(4, 'buas'),
(5, 'elektronik'),
(6, 'fashion'),
(7, 'rumah tangga'),
(8, 'buku'),
(9, 'kesehatan'),
(10, 'kecantikan'),
(11, 'makanan dan minuman'),
(12, 'mainan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentar`
--

CREATE TABLE `komentar` (
  `komentarID` int(20) NOT NULL,
  `fotoID` int(20) NOT NULL,
  `userID` int(20) NOT NULL,
  `komentar_isi` text NOT NULL,
  `komentar_tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `likefoto`
--

CREATE TABLE `likefoto` (
  `likeID` int(20) NOT NULL,
  `userID` int(20) NOT NULL,
  `fotoID` int(20) NOT NULL,
  `like_tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `likefoto`
--

INSERT INTO `likefoto` (`likeID`, `userID`, `fotoID`, `like_tanggal`) VALUES
(76, 3, 42, '0000-00-00'),
(77, 3, 36, '0000-00-00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `userID` int(20) NOT NULL,
  `user_namalengkap` varchar(255) NOT NULL,
  `user_username` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_alamat` text NOT NULL,
  `user_biodata` varchar(255) NOT NULL,
  `user_aboutme` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_avatar` varchar(255) NOT NULL,
  `user_tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`userID`, `user_namalengkap`, `user_username`, `user_email`, `user_alamat`, `user_biodata`, `user_aboutme`, `user_password`, `user_avatar`, `user_tanggal`) VALUES
(3, 'danielsaferius', 'Admin', 'Admin123@gmail.com', 'jalalalass', 'pelajar', 'dadada', '$2y$10$/J9yF8K5P2t0IWgzew2yzekCDhFMyted5Fy8xzuOBy/mmaJsIQ8RK', 'e2d185615812388194d411e764bdce73.png', '2024-02-26'),
(4, 'danielsaferius', 'Admin2', 'Admin2@gmail.com', 'jalan perkasa gg peraksa 7', '', '', '$2y$10$A84qj/6T4o7ltjPSB2R/WuvET8pjVRZVysMTtcGnlZn5SzAtAKRNa', '48983f21d8ca47b0b01d7b3aabe14981.png', '2024-02-26');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`albumID`),
  ADD KEY `userID` (`userID`);

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`fotoID`),
  ADD KEY `kategoriID` (`kategoriID`,`albumID`,`userID`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kategoriID`);

--
-- Indeks untuk tabel `komentar`
--
ALTER TABLE `komentar`
  ADD PRIMARY KEY (`komentarID`),
  ADD KEY `fotoID` (`fotoID`,`userID`);

--
-- Indeks untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`likeID`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `albumID` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `fotoID` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `kategoriID` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `komentar`
--
ALTER TABLE `komentar`
  MODIFY `komentarID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `likeID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
